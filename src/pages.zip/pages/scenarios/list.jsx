import { List as AntdList } from "antd";
import { List,useSimpleList  } from "@refinedev/antd";

import ScenarioItem from "./ScenarioItem";
const functionTest=(jsonObject)=>{
    let text = JSON.stringify(jsonObject);

    console.log("functionTest", text);

   // let text = "This is a {{sample}} string with {{multiple}} values.";
let myvariables = {'sample':'mysimpledata', 'multiple':'multiplemydata'};

// Regular expression pattern to match values between {{ and }}
let pattern = /\{\{([^}]+)\}\}/g;

// Find all matches
let matches = text.match(pattern);

// Replace matches with values from myvariables
let replacedText = text.replace(pattern, (match, key) => {
    // Check if the key exists in myvariables
    if (myvariables.hasOwnProperty(key)) {
        // Replace the match with the corresponding value from myvariables
        return myvariables[key];
    }
    // If key not found, return the original match
    return match;
});

console.log(replacedText);
    return "functionTest harish ";
}
export const ScenarioList = () => {
    const { listProps } = useSimpleList({
        resource: "scenarios",
        metaData: { populate: ["steps"] },
        pagination: {
            pageSize: 200,
          },
    });
    const myobj={"name":"harish{{sample}}","age":30,"city":"bangalore"}
    console.log("functionTest",functionTest(myobj));


    return (
        <div>
           
            <List >
                <AntdList
                    grid={{ gutter: 16, xs: 1 }}
                    style={{
                        justifyContent: "center",
                    }}
                    {...listProps}
                    renderItem={(item) => {
                        return <AntdList.Item>
                            <ScenarioItem item={item} />
                        </AntdList.Item>
                    }}
                />
            </List>

        </div>
    )
}